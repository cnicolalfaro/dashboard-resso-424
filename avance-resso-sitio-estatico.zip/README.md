# Avance RESSO — sitio estático

Exportación estática del tablero "Avance RESSO" (SKIC 424 · RESSO / CODELCO), lista para GitHub Pages o cualquier hosting estático. No requiere servidor, build, API ni login.

## Contenido

- `index.html` — página única, sin frameworks.
- `style.css` — todos los estilos.
- `data.js` — el snapshot de datos (`const DATA = {...}`), generado 2026-09-22 08:32. Es una foto fija: no se actualiza sola.
- `app.js` — toda la lógica de render (KPIs, gráfico, tabla de personas, filtros). No hace ninguna llamada de red ni usa `fetch`/`localStorage`; todo corre en memoria a partir de `DATA`.

Los tres archivos se cargan con `<script src="...">` normal (no `fetch`), justamente para que la página funcione abriendo `index.html` directo desde el disco (`file://`), sin servidor — un `fetch` a un archivo local falla por CORS en Chrome si no hay servidor, esto lo evita.

## Cómo verificar que funciona

Doble clic en `index.html` (o arrastrarlo a una pestaña del navegador). Debería verse igual que el dashboard original: KPIs arriba, gráfico de torta, lista de documentos por familia, y la tabla de personas con buscador y filtros.

Ya lo probé abriendo el archivo tal cual (protocolo `file://`, sin servidor) con un navegador headless: carga los 68 documentos y las 989 personas, el buscador filtra bien, y los grupos se abren/cierran al hacer clic — sin errores de JavaScript.

## Publicarlo en GitHub Pages

1. Crea un repositorio (o usa uno existente) y sube estos 4 archivos a la raíz (o a una carpeta, ej. `/docs`).
2. En GitHub: **Settings → Pages → Source**, elige la rama y carpeta donde quedaron los archivos.
3. GitHub te da una URL tipo `https://<usuario>.github.io/<repo>/` — ábrela y debería verse igual.

No hace falta ningún paso de build: son archivos estáticos tal cual.

## Única dependencia externa: Google Fonts

`index.html` carga las tipografías (Oswald, IBM Plex Sans, IBM Plex Mono) desde `fonts.googleapis.com` — es un recurso web normal, no depende de Claude ni de este workspace, y sigue funcionando en GitHub Pages sin ningún cambio. Si en algún momento quieres que el sitio funcione 100% sin internet (por ejemplo para verlo desde un computador sin conexión), avísame y puedo dejar las fuentes incluidas como archivos dentro del proyecto; mientras tanto, si Google Fonts no carga (sin internet), el sitio se ve igual pero con la tipografía de reemplazo del sistema en vez de Oswald/IBM Plex — no se rompe nada, solo cambia la letra.

## Actualizar los datos

Este export es una foto fija del dashboard al 2026-09-22 08:32. El dashboard "vivo" en Cowork sigue actualizándose solo todos los días; este sitio estático no. Para refrescar los datos aquí, hay que volver a pedir la exportación (o reemplazar el contenido de `data.js` por un nuevo `const DATA = {...}` con la misma estructura).

## Notas técnicas

- Sin dependencias de build ni npm: es HTML/CSS/JS plano.
- Sin sesión, sin API, sin backend.
- `app.js` no modifica `data.js`: todo el filtrado/búsqueda ocurre en memoria del navegador de quien lo visita.
